echo "Hello world , welcome to PHP base app";
echo phpinfo();
